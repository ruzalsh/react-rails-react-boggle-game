import React from "react";
import {connect} from "react-redux";
import {validate} from "../store/actions/BoggleAction";


class Boggle extends React.Component {

    render(){
        return (
            <div>aaaaaaaaaaaa</div>
        )
    }
}